function encontrarMaior() {
    // Recebe os dois valores
    let valor1 = parseFloat(document.getElementById("valor1").value);
    let valor2 = parseFloat(document.getElementById("valor2").value);

    // Encontra o maior valor
    let maior = Math.max(valor1, valor2);

    // Imprime o resultado
    let resultado = document.getElementById("resultado");
    resultado.innerHTML = `O maior valor: ${maior}`;
}