function calcular() {
    const cotacao = parseFloat(document.getElementById("cotacao").value);
    const resultadoDiv = document.getElementById("resultado");

    if (isNaN(cotacao) || cotacao <= 0) {
        resultadoDiv.innerHTML = "Por favor, insira uma cotação válida.";
        return;
    }

    const variacoes = [
        { porcentagem: 1, texto: "+1%" },
        { porcentagem: 2, texto: "+2%" },
        { porcentagem: 5, texto: "+5%" },
        { porcentagem: 10, texto: "+10%" },
    ];

    const resultadoHtml = variacoes.map((variacao) => {
        const valor = cotacao * (1 + variacao.porcentagem / 100);
        return `<p>${variacao.texto}: R$ ${valor.toFixed(2)}</p>`;
    }).join("");

    resultadoDiv.innerHTML = resultadoHtml;
}