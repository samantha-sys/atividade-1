function calcularValor() {
    // Recebe os valores digitados nos campos
    let valorQuilo = parseFloat(document.getElementById("valorQuilo").value);
    let quantidadeQuilos = parseFloat(document.getElementById("quantidadeQuilos").value);

    // Verifica se os campos foram preenchidos corretamente
    if (isNaN(valorQuilo) || isNaN(quantidadeQuilos)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha os dois campos corretamente.";
        return;
    }

    // Calcula o valor final
    let valorFinal = valorQuilo * quantidadeQuilos;

    // Exibe o resultado formatado com duas casas decimais
    document.getElementById("resultado").innerHTML = `Valor final: R$ ${valorFinal.toFixed(2)}`;
}