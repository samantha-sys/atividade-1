function calcular() {
    const saldo = parseFloat(document.getElementById('saldo').value);
    const resultado = document.getElementById('resultado');

    if (isNaN(saldo)) {
        resultado.textContent = "Por favor, informe um valor válido.";
    } else {
        const novoSaldo = saldo + (saldo * 0.01);
        resultado.textContent = `Novo saldo com reajuste: R$ ${novoSaldo.toFixed(2)}`;
    }
}