function calcularPedido() {
  const sabor1 = document.getElementById("sabor1").value.trim();
  const sabor2 = document.getElementById("sabor2").value.trim();
  const sabor3 = document.getElementById("sabor3").value.trim();
  const sabor4 = document.getElementById("sabor4").value.trim();
  const refrigerantes = parseInt(document.getElementById("refrigerantes").value) || 0;

  const precoPizza = 12;
  const precoRefri = 7;

  const sabores = [sabor1, sabor2, sabor3, sabor4].filter(sabor => sabor !== "");
  const totalPizza = sabores.length * precoPizza;
  const totalRefri = refrigerantes * precoRefri;
  const total = totalPizza + totalRefri;

  let resultadoHTML = "";

  if (sabores.length > 0) {
resultadoHTML += `<p><strong>Sabores escolhidos:</strong></p><ul>`;
    sabores.forEach(sabor => {
      resultadoHTML += `<li>${sabor}</li>`;
    });
    resultadoHTML += `</ul>`;
  }

  resultadoHTML += `<p><strong>Refrigerantes:</strong> ${refrigerantes}</p>`;
  resultadoHTML += `<p><strong>Total a pagar:</strong> R$ ${total.toFixed(2)}</p>`;

  document.getElementById("resultado").innerHTML = resultadoHTML;
}