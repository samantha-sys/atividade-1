function calcular() {
    const num1 = parseInt(document.getElementById("num1").value);
    const num2 = parseInt(document.getElementById("num2").value);
    const resultado = document.getElementById("resultado");

    if (isNaN(num1) || isNaN(num2)) {
        resultado.innerHTML = "Por favor, insira dois números válidos.";
        return;
    }

    const operacoes = [
        { nome: "Soma", resultado: num1 + num2 },
        { nome: "Subtração", resultado: num1 - num2 },
        { nome: "Multiplicação", resultado: num1 * num2 },
        { nome: "Divisão", resultado: num2 !== 0 ? (num1 / num2).toFixed(2) : "Divisão por zero" },
    ];

    const listaOperacoes = operacoes.map((operacao) => {
        return `<p>${operacao.nome}: ${operacao.resultado}</p>`;
    }).join("");

    resultado.innerHTML = listaOperacoes;
}