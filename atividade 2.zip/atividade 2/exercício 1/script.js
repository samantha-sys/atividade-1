function calcularArea() {
    const largura = parseFloat(document.getElementById("largura").value);
    const comprimento = parseFloat(document.getElementById("comprimento").value);
    const resultadoDiv = document.getElementById("resultado");

    if (isNaN(largura) || isNaN(comprimento) || largura <= 0 || comprimento <= 0) {
        resultadoDiv.innerHTML = "<span style='color: red'>Informe valores válidos para largura e comprimento.</span>";
        return;
    }

    const area = largura * comprimento;
    resultadoDiv.innerHTML = `A área do terreno é <strong>${area.toFixed(2)} m²</strong>.`;
}