function calcularFerraduras() {
    const cavalos = parseInt(document.getElementById("cavalos").value);
    const resultadoDiv = document.getElementById("resultado");

    if (isNaN(cavalos) || cavalos <= 0) {
        resultadoDiv.innerHTML = "<span style='color: red'>Informe uma quantidade válida de cavalos.</span>";
        return;
    }

    const ferraduras = cavalos * 4;
resultadoDiv.innerHTML = `Você precisa de <strong>${ferraduras}</strong> ferraduras para ${cavalos} cavalos.`;
}