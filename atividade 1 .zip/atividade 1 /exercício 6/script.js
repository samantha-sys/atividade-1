function mostrarMenor() {
    let v1 = parseFloat(document.getElementById("valor1").value);
    let v2 = parseFloat(document.getElementById("valor2").value);
    let v3 = parseFloat(document.getElementById("valor3").value);
    let v4 = parseFloat(document.getElementById("valor4").value);

    if (isNaN(v1) || isNaN(v2) || isNaN(v3) || isNaN(v4)) {
        document.getElementById("resultado").innerText = "Preencha todos os campos.";
        return;
    }

    let menor = Math.min(v1, v2, v3, v4);
    document.getElementById("resultado").innerText = menor.toFixed(2);
}