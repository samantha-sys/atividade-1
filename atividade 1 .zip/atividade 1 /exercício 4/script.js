function calcularMedias() {
    // Recebe os três números
    let n1 = parseFloat(document.getElementById("n1").value);
    let n2 = parseFloat(document.getElementById("n2").value);
    let n3 = parseFloat(document.getElementById("n3").value);

    // Calcula a média aritmética
    let mediaAritmetica = (n1 + n2 + n3) / 3;

    // Calcula a média ponderada com pesos 3, 2 e 5
    let mediaPonderada = (n1 * 3 + n2 * 2 + n3 * 5) / (3 + 2 + 5);

    // Calcula a soma das duas médias
    let somaMedias = mediaAritmetica + mediaPonderada;

    // Calcula a média das médias
    let mediaDasMedias = (mediaAritmetica + mediaPonderada) / 2;

    // Imprime os resultados
    let resultado = document.getElementById("resultado");
    resultado.innerHTML = `
        <p>Média aritmética: ${mediaAritmetica.toFixed(2)}</p>
        <p>Média ponderada: ${mediaPonderada.toFixed(2)}</p>
        <p>Soma das médias: ${somaMedias.toFixed(2)}</p>
        <p>Média das médias: ${mediaDasMedias.toFixed(2)}</p>
    `;
}